const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const pdf = new Schema({
    bname:String,
    author:String,
    description:String,
    pdfs:String,
    created_at:{ type: Date, default: Date.now }
});
module.exports = mongoose.model('pdf',pdf);