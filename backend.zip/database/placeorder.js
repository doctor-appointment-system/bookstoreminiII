const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const placeorder = new Schema({
    email:String,
    pname:String,
    image:String,
    quantity:Number,
    price:Number,
    date:{ type: Date, default: Date.now }
});
module.exports = mongoose.model('placeorder',placeorder);