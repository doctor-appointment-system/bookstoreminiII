const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const mycart = new Schema({
    email:String,
    pname:String,
    image:String,
    quantity:Number,
    price:Number
});
module.exports = mongoose.model('mycart',mycart);