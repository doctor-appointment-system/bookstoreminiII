
const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const cart = new Schema({
	image:String,
   email:String,
   pname:String,
   quantity:String,
    price:Number
    
});
module.exports = mongoose.model('cart',cart);