const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const sha1=require('sha1');
const mongoose=require('mongoose');
const nodemailer = require('nodemailer');

//for uploading
const multer=require('multer');
const path="./attach";
let storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null,path)
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now()+ '.' + file.originalname.split('.')[file.originalname.split('.').length -1])
    }
  })
  
  let upload = multer({ storage: storage }).single('Image');
  let upload1 = multer({ storage: storage }).single('PDF');
 

  //Node mailer

  const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'karondiyan1999@gmail.com',
    pass: 'gulagula'
  }
});


//connect mongoose to mongoDb

mongoose.connect("mongodb://localhost/myminiproject",{
	useCreateIndex:true,
	useNewUrlParser:true
});

let adminLogin=require('./database/adminlogin');
let catModel=require('./database/category');
let proModel=require('./database/product');
let feedModel=require('./database/feedback');
let pdfModel=require('./database/pdf');
//let cartModel=require('./database/cart');
let signModel=require('./database/signup');
let mycartModel=require('./database/mycart');
let placeModel=require('./database/placeorder');
let orderModel=require('./database/order');

let app=express();
app.use(cors());
app.use(bodyParser.json());
app.use('/images',express.static('attach'));

app.post('/api/adminlogin',function(req,res){
	let email=req.body.name;
	let password=(req.body.password);
  console.log(email);
  console.log(password);

	adminLogin.find({'email':email,'password':password},function(err,data){
		if (err){}
			else if (data.length==0){
				res.json({'err':1,'msg':'*username or password is not correct'});
			}
			else{
				res.json({'err':0,'msg':'Login Success','user':email});
			}
	})
})


//addcategory 
app.post('/api/addCategory',function(req,res)
{
   upload(req,res,function(err)
   {
       if(err){}
       else
       {
           let cname=req.body.cname;
           let description=req.body.description;
           let imgname=req.file.filename;
           let ins=new catModel({'cname':cname,'description':description,'image':imgname});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'category Saved'})
               }
           })
       }
   })
})

//addPDF

app.post('/api/addpdf',function(req,res)
{
   upload1(req,res,function(err)
   {
       if(err){}
       else
       {
           let bname=req.body.bname;
           let author=req.body.author;
           let description=req.body.description;
           let pdf=req.file.filename;
           console.log(bname+" "+author+" "+description+" "+pdf);
           let ins=new pdfModel({'bname':bname,'author':author,'description':description,'pdfs':pdf});
           ins.save(function(err)
           {
               if(err){
                console.log(err);
               }
               else
               {
                   res.json({'err':0,'msg':'pdf Saved'})
               }
           })
       }
   })

//    upload2(req,res,function(err){
//     if (err){}
//       else{
//         let img=req.file.filename;
//         console.log(img);
//       }
//    })
 })

//get pdf

app.get('/api/show',function(req,res){
  pdfModel.find({},function(err,data){
    if (err){}
      else{
         res.json({'err':0,'data':data})
      }
  })
})

app.post('/api/downloadpdf/:pdf',function(req,res){
  if (err){}
})

//edit category
app.post('/api/editCategory/:id',function(req,res)
{
   upload(req,res,function(err)
   {
       if(err){}
       else
       {
           let id=req.body.id;
           let cname=req.body.cname;
           let description=req.body.description;
           let imgname=req.file.filename;

           catModel.find({'_id':id},function(err,data){
            if(err){}
              else{
                let cat=data[0].cname;
                proModel.update({'cname':cat},{$set:{'cname':cname}},function(err){
                  if (err){}
                    else{
                      console.log("product category changed");
                    }
                })
              }
           })
          catModel.update({'_id':id},{$set:{'cname':cname,'description':description,'created_at':Date.now(),'image':imgname}},function(err){
            if (err){}
              else{
                res.json({'err':0,'msg':'category edit'})
              }
          })
       }
   })
})


// get category

app.get('/api/getCategory',function(req,res){
  catModel.find({},function(err,data){
    if (err){
      res.json({'err':1,'msg':'some error'})
    }
    else{
      res.json({'err':0,'cdata':data})
    }

  })
})


//delcat
app.get('/api/delcat/:id',function(req,res)
{
    let catid=req.params.id;

    catModel.find({'_id':catid},function(err,data){
      if (err){}
        else{
        let  category=data[0].cname;
          console.log(category);
     proModel.remove({'cname':category},function(err){
          if (err){
          }
            else{
              console.log("product deleted");
            }
        })
   }
 })
   
        catModel.remove({'_id':catid},function(err)
    {
        if(err){}
        else
        {
          res.json({'err':0,'msg':'category deleted'});
        }
    })

       

   //      proModel.remove({'cname':category},function(err){
   //        if (err){}
   //          else{
   //              res.json({'err':0,'msg':'product deleted'});
   //          }
   //      })
   //    }
   // })
})

// deleter product

app.get('/api/delpro/:id',function(req,res)
{
    let catid=req.params.id;
    proModel.remove({'_id':catid},function(err)
    {
        if(err){}
        else
        {
          res.json({'err':0,'msg':'product deleted'});
        }
    })
})

//fetch cat by id 
app.get('/api/fetchcatbyid/:id',function(req,res)
{
    let cid=req.params.id;
    catModel.find({'_id':cid},function(err,data)
    {
        if(err){}
        else{
            res.json({'err':0,'cdata':data});
        }
    })
})

//change password

app.post('/api/changepassword',function(req,res){

let email=req.body.email;
  let op=sha1(req.body.op);
  let np=sha1(req.body.np);

 

  adminLogin.find({'email':email},function(err,data){
    if (err){
    }
      else{
        let pass=data[0].password;
        if(op==pass){
adminLogin.update({'email':email},{$set:{'password':np}},function(err){
    if (err){
    }
      else{
        res.json({'err':0,'msg':'password change'});
      }
  })
}
else
{
  res.json({'err':1,'msg':'old password is not correct'});
}
      }
  })

  
})

//add product
app.post('/api/addProduct',function(req,res)
{
   upload(req,res,function(err)
   {
       if(err){}
       else
       {
           let cname=req.body.cname;
           let pname=req.body.pname;
           let description=req.body.description;
           let brand=req.body.brand;
           let price=req.body.price;
           let imgname=req.file.filename;
           let ins=new proModel({'cname':cname,'pname':pname,'description':description,'brand':brand,'price':price,'image':imgname});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'product Saved'})
               }
           })
       }
   })
})

//get product

app.get('/api/getProduct',function(req,res){
  proModel.find({},function(err,data){
    if (err){
      res.json({'err':1,'msg':'some error'})
    }
    else{
      res.json({'err':0,'data':data})
    }

  })
})


app.get('/api/getfilter/:d',function(req,res){

  let cat=req.params.d;
  proModel.find({'cname':cat},function(err,data){
   if(err){
    res.json({'err':1,'msg':'some error'});
   }
   else{
     res.json({'err':0,'data':data});
   }
  })
})

// edit product
app.post('/api/editProduct/:id',function(req,res)
{
   upload(req,res,function(err)
   {
       if(err){}
       else
       {
           let id=req.body.id;
           let pname=req.body.pname;
           let description=req.body.description;
           let brand=req.body.brand;
           let price=req.body.price;
           let imgname=req.file.filename;
          proModel.update({'_id':id},{$set:{'pname':pname,'description':description,'brand':brand,'price':price,'created_at':Date.now(),'image':imgname}},function(err){
            if (err){}
              else{
                res.json({'err':0,'msg':'product edit'})
              }
          })
       }
   })
})

//fetch product by id

app.get('/api/fetchcatbypid/:id',function(req,res)
{
    let cid=req.params.id;
    proModel.find({'_id':cid},function(err,data)
    {
        if(err){}
        else{
            res.json({'err':0,'cdata':data});
        }
    })
})


//get product at front side

app.get('/api/getproduct/:cname',function(req,res){
  let cname=req.params.cname;
  console.log(cname);
  proModel.find({'cname':cname},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'pdata':data});
      }
  })
})


//send feedback

app.post('/api/feedback',function(req,res)
{

           let name=req.body.name;
           let email=req.body.email;
           let message=req.body.message;
           let subject=req.body.subject;
           let ins=new feedModel({'name':name,'email':email,'subject':subject,'message':message});
           ins.save(function(err)
           {
               if(err){}
               else
               {
               let mailOptions = {
                   from: 'karondiyan1999@gmail.com',
                   to: 'karondiyan1999@gmail.com',
                   subject: 'Sending Email using Node.js',
                   text: 'Hello!! I am sending a mail through nodemailer'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
    res.json({'err':1,'msg':'Not send'});
  } else {
    console.log('Email sent: ' + info.response);
    res.json({'err':0,'msg':'Send Successfully'});
  }
});
               }
           })
})



//send reply

app.post('/api/reply',function(req,res)
{

          let id=req.body.id;
          let reply=req.body.reply;
          console.log(id+" "+reply);
          feedModel.find({'_id':id},function(err,data){
               if(err){}
               else
               {
               let mailOptions = {
                   from: 'karondiyan1999@gmail.com',
                   to: data[0].email,
                   subject:'Book Store reply',
                   text: reply
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
    res.json({'err':1,'msg':'Not send'});
  } else {
    console.log('Email sent: ' + info.response);
    res.json({'err':0,'msg':'Send Successfully'});
  }
});
}
           })    
           })



// fetch producr details
app.get('/api/productdetails/:id',function(req,res){

  let id=req.params.id;
  proModel.find({'_id':id},function(err,data){
   if(err){
    res.json({'err':1,'msg':'some error'});
   }
   else{
     res.json({'err':0,'pdata':data});
   }
  })
})


//delete feedback

app.get('/api/deletefeed/:id',function(req,res){
  let id=req.params.id;
  feedModel.remove({'_id':id},function(err){
    if (err){}
      else{
              res.json({'err':0,'msg':'delete Successfully'});
      }
  })
})


//add cart
app.post('/api/addcart',function(req,res){

  let id=req.body.id;
 // console.log(id+" "+userId);
  proModel.find({'_id':id},function(err,data){
   if(err){
    res.json({'err':1,'msg':'some error'});
   }
   else{
     upload(req,res,function(err)
   {
       if(err){}
       else
       {
       let userId=req.body.userId;
    let image=data[0].image;
    let pname=data[0].pname;
    let price=data[0].price;
    let quantity=1;
    console.log(image+" "+pname+" "+price+" "+userId);
    let ins=new mycartModel({'email':userId,'pname':pname,'quantity':quantity,'price':price,'image':image});
           ins.save(function(err)
           {
               if(err){
                console.log(err);
               }
               else
               {
                   res.json({'err':0,'msg':'cart saved'});
                 }
           })

   
   }
 })
   }
})
})


//get cart data
app.get('/api/getcartdata/:id',function(req,res){
  let id=req.params.id;
  mycartModel.find({'email':id},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'data':data});
      }
  })
})

// add quantity
app.post('/api/addquantity',function(req,res){
  let pname=req.body.pname;
  let value=req.body.value;
  let id=req.body.id;
  console.log(value+" "+pname+" "+id);
  mycartModel.update({'email':id,'pname':pname},{$set:{'quantity':value}},function(err){
    if (err){}
      else{
        res.json({'err':0,'msg':'quantity added'});
      }
  })
})

//get total
app.get('/api/total/:id',function(req,res){
  let id=req.params.id;
  console.log(id);
  sum=0;
  mycartModel.find({'email':id},function(err,data){
    if (err){}
      else{
       for (i=0;i<data.length;i++){
        sum=sum+parseInt(data[i].quantity)*parseInt(data[i].price);
       }
      res.json({'err':0,'data':data,'sum':sum});
      }
  })
})


//search bar

app.get('/api/search/:value',function(req,res){
  let value=req.params.value;
  console.log(value);
  proModel.find({ $or:[{ 'cname': value },{ 'pname': value }]},function(err,data){
    if (err){
    }
      else{
        if (data.length==0){
        res.json({'err':0,'msg':'not found'});
        }
        else {
          if (value==data[0].cname){
          res.json({'err':1,'data':data});
        }
        else if (value==data[0].pname){
          res.json({'err':2,'data':data});
        }
      }
      }
  })
})


//product search

app.get('/api/productsearch/:pname',function(req,res){
  let pname=req.params.pname;
proModel.find({'pname':pname},function(err,data){
  if (err){}
    else{
      res.json({'err':0,'data':data});
    }
})
})

//signup site

app.post('/api/signup',function(req,res){
  let name=req.body.name;
  let email=req.body.email;
  let password=sha1(req.body.signpass);
  let mobile=req.body.mobileno;

  signModel.find({"email":email},function(err,data){
    if (err){}
      else{
        if (data.length==0){
        let ins=new signModel({'name':name,'email':email,'password':password,'mobile':mobile});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'data saved'});
                 }
           })
      }
      else
        res.json({'err':1,'msg':'This Email is already taken'});
    }
  })

   


})


//login site

app.post('/api/login',function(req,res){
  let email=req.body.email;
  let password=sha1(req.body.logpass);

  signModel.find({'email':email,'password':password},function(err,data){
    if (err){}
      else if (data.length==0){
        res.json({'err':1,'msg':'*username or password is not correct'});
      }
      else{
        res.json({'err':0,'user':data});
      }
  })
})

// Remove cart element
app.get('/api/remove/:id',function(req,res){
  let id=req.params.id;
  mycartModel.remove({'_id':id},function(err){
    if (err){}
      else{
        res.json({'err':0,'msg':'cart element deleted'});
      }
  })
})

//place order

app.get('/api/placeorder/:id',function(req,res){
  mycartModel.find({},function(err,data){
     if (err){}

      else{

   upload(req,res,function(err)
   {
       if(err){}

        else{
          let userId=req.params.id;
        for (i=0;i<data.length;i++){
          let email=data[i].email;
          let pname=data[i].pname;
          let price=data[i].price;
          let image=data[i].image;
          let quantity=data[i].quantity;

           if (email==userId){
        let ins=new placeModel({'email':email,'pname':pname,'quantity':quantity,'price':price,'image':image,'date':Date.now()});
           ins.save(function(err)
           {
               if(err){
               }
               else
               {
                 }
           })

         mycartModel.remove({'email':userId},function(err){
          if (err){}
            else{
            }
         })
       }
      }
         res.json({'err':0,'msg':'order saved'});
      }
      })
 }
    })
  })

// confirm order

app.post('/api/confirmorder',function(req,res){
  let sum=0;
  let email=req.body.userId;
  let name=req.body.name;
  let address=req.body.address;
  let district=req.body.district;
  let pin=req.body.pin;
  let number=req.body.number;

//console.log(email+" "+name+" "+address+" "+district+" "+pin+" "+number);

  placeModel.find({'email':email},function(err,data){
    if (err){}
      else{
      for (i=0;i<data.length;i++){
        //console.log(data[i].quantity);
        sum=sum+data[i].price*data[i].quantity;
      }
      console.log(sum);

       let ins=new orderModel({'email':email,'name':name,'address':address,'district':district,'pin':pin,'number':number,'total':sum});
           ins.save(function(err)
           {
               if(err){
               }
               else
               {
                   res.json({'err':0,'msg':'order confirmed'});
                 }
           })
      }
  })

   

})

//details

app.get('/api/details/:id',function(req,res){
  let id=req.params.id;
  //console.log(id+" "+"fshgfsss");
  orderModel.find({'email':id},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'data':data});
      }
  })
})


//order 

app.get('/api/order',function(req,res){
  placeModel.find({},function(err,data){
    if (err){}
      else{
        let sum=0;
        for (i=0;i<data.length;i++){
          sum=sum+data[i].price*data[i].quantity;
        }
        res.json({'err':0,'data':data,'sum':sum});
      }
  })
})


//default section

app.get('/api/defaultpro',function(req,res){
  proModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'data':data});
      }
  })
})


//feedback admin panel

app.get('/api/feedbackshow',function(req,res){
  feedModel.find({},function(err,data){
    if (err){}
      else{
         res.json({'err':0,'data':data});
      }
  })

})


//order detais component admin panel

app.get('/api/orderdetail',function(req,res){
  orderModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'data':data});
      }
  })
})


//fetch products by 

app.get('/api/fetchproduct',function(req,res){
  placeModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'data':data});
      }
  })
})

app.listen(8086,function(){
	console.log("Works on 8086");
})